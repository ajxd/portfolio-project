import React, { useEffect, useRef } from "react";
import { Canvas } from "@react-three/fiber"; // For 3D graphics
import FluidAnimation from "./FluidAnimation.tsx"; // Your existing fluid animation
import "@fontsource/montserrat/800.css"; // Montserrat font
import { gsap } from "gsap";
import { motion } from "framer-motion";

const App: React.FC = () => {
  const textRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Entry animation for the text
    const textElements = textRef.current?.querySelectorAll(".letter");

    if (textElements) {
      gsap.fromTo(
        textElements,
        { opacity: 0, y: 50, rotateX: 90, transformOrigin: "50% 50%" },
        {
          opacity: 1,
          y: 0,
          rotateX: 0,
          duration: 1.2,
          stagger: 0.1,
          ease: "power4.out",
        }
      );
    }
  }, []);

  const renderText = (text: string) =>
    text.split("").map((char, index) => (
      <span
        key={index}
        className="letter"
        style={{
          display: "inline-block",
          margin: "0 5px", // Add spacing between letters
          perspective: "400px",
          transformStyle: "preserve-3d",
        }}
      >
        {char}
      </span>
    ));

  return (
    <div
      style={{
        position: "relative",
        height: "100vh",
        overflow: "hidden",
        backgroundColor: "#000",
        color: "#fff",
      }}
    >
      {/* 3D Background */}
      <Canvas
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          zIndex: 0,
        }}
      >
        {/* Add 3D objects, lights, and animations here */}
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
      </Canvas>

      {/* Fluid Animation */}
      <FluidAnimation opacity={0.5} />

      {/* Portfolio Content */}
      <div
        ref={textRef}
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          zIndex: 2,
          textAlign: "center",
          userSelect: "none",
          fontFamily: "Montserrat, sans-serif",
        }}
      >
        {/* Animated Heading */}
        <motion.h1
          style={{
            fontWeight: 800,
            fontSize: "84px",
            textTransform: "uppercase",
            letterSpacing: "0.1em",
            margin: 0,
          }}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
        >
          {renderText("WELCOME TO MY PORTFOLIO")}
        </motion.h1>

        {/* Call-to-Action Buttons */}
        <motion.div
          style={{
            marginTop: "20px",
            display: "flex",
            justifyContent: "center",
            gap: "20px",
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 1 }}
        >
          <motion.button
            whileHover={{
              scale: 1.1,
              backgroundColor: "#00ffff",
              boxShadow: "0px 0px 20px #00ffff",
            }}
            style={{
              backgroundColor: "#fff",
              color: "#000",
              border: "none",
              padding: "15px 30px",
              fontSize: "18px",
              fontWeight: 600,
              cursor: "pointer",
              borderRadius: "5px",
              outline: "none",
              textTransform: "uppercase",
            }}
            onClick={() => alert("View Projects Clicked!")}
          >
            View Projects
          </motion.button>
          <motion.button
            whileHover={{
              scale: 1.1,
              backgroundColor: "#ff69b4",
              boxShadow: "0px 0px 20px #ff69b4",
            }}
            style={{
              backgroundColor: "#fff",
              color: "#000",
              border: "none",
              padding: "15px 30px",
              fontSize: "18px",
              fontWeight: 600,
              cursor: "pointer",
              borderRadius: "5px",
              outline: "none",
              textTransform: "uppercase",
            }}
            onClick={() => alert("Contact Me Clicked!")}
          >
            Contact Me
          </motion.button>
        </motion.div>
      </div>
    </div>
  );
};

export default App;
