import React, { useRef, useEffect } from "react";
import Fluid from "webgl-fluid";

interface FluidAnimationProps {
  opacity?: number;
}

const FluidAnimation: React.FC<FluidAnimationProps> = ({ opacity = 1 }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;

    if (canvas) {
      // Ensure Fluid initializes properly
      const fluidInstance = Fluid(canvas);

      // Type assertion for the splat method
      const splat = (fluidInstance as any)?.splat;

      if (!fluidInstance || typeof splat !== "function") {
        console.error("Failed to initialize Fluid instance or 'splat' is not a function.");
        return;
      }

      const handleMouseMove = (event: MouseEvent) => {
        const rect = canvas.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;

        try {
          splat(x, y, 300, [Math.random(), Math.random(), Math.random()]);
        } catch (error) {
          console.error("Error calling splat on Fluid instance:", error);
        }
      };

      canvas.addEventListener("mousemove", handleMouseMove);

      return () => {
        canvas.removeEventListener("mousemove", handleMouseMove);
      };
    } else {
      console.error("Canvas reference is null.");
    }
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        zIndex: 1,
        opacity,
      }}
    />
  );
};

export default FluidAnimation;
